delta_x = 2;
x = 2.12;
x2 = x + delta_x;


%f(x) = 3e^(2.5x)+2

y2 = 3*e^(2.5*x2)+2;

y1 = 3*e^(2.5*x)+2;

FDD = (y2-y1)/delta_x;


ExactValue = (15*exp((5*2.12)/2))/2; % got this from FDD_BDD_CDD_Exact.m this is the exact value of the eqn f(x)


fprintf('The Exact value is: %g\n', ExactValue);

fprintf('The value of FDD is: %g\n', FDD);

Error=abs(((ExactValue-FDD)/ExactValue)*100);
disp(['The absolute error is: ', num2str(Error)]);


delta_x = 2;
x=2.12
x2 = x;
x1 = x - delta_x;


%f(x) = 3e^(2.5x)+2

y2 = 3*e^(2.5*x2)+2;

y1 = 3*e^(2.5*x1)+2;

BDD = (y2-y1)/delta_x;


ExactValue = (15*exp((5*2.12)/2))/2; % got this from FDD_BDD_CDD_Exact.m this is the exact value of the eqn f(x)


fprintf('The Exact value is: %g\n', ExactValue);

fprintf('The value of BDD is: %g\n', BDD);

Error=abs(((ExactValue-BDD)/ExactValue)*100);
disp(['The absolute error is: ', num2str(Error)]);


delta_x = 2;
x = 2.12;
x2 = x+delta_x;
x1 = x - delta_x;


%f(x) = 3e^(2.5x)+2

y2 = 3*e^(2.5*x2)+2;

y1 = 3*e^(2.5*x1)+2;

CDD = (y2-y1)/(2*delta_x);


ExactValue = (15*exp((5*2.12)/2))/2; % got this from FDD_BDD_CDD_Exact.m this is the exact value of the eqn f(x)


fprintf('The Exact value is: %g\n', ExactValue);

fprintf('The value of CDD is: %g\n', CDD);

Error=abs(((ExactValue-CDD)/ExactValue)*100);
disp(['The absolute error is: ', num2str(Error)]);

