n = 6;
factVal = 1;
for i=1:n
    factVal = factVal*i;
endfor
factVal

v0=20;
g=9.8;
t=0;
y=0;
time=[];
location=[];
while y>=0
    disp(['At time t = ',num2str(t),' Location = ',num2str(y)])
    y = v0*t-g*t^2/2;
    t=t+0.1;
    time=[time,t];
    location=[location,y];
endwhile

title ("Time vs. Location");
xlabel ("Time");
ylabel ("Location");
plot (sin(time),cos(location),"--r", time, location,"-go");
legend ('Tan','original')
