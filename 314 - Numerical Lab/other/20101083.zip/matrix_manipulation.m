marks=[91,92,93;94,95,96;97,98,99;91,95,99;91,94,97]

eva_marks=[91,94,97,91,91]



eva_total_mark=sum(eva_marks)


all_marksin50scale=[91,92,93;94,95,96;97,98,99;91,95,99;91,94,97]*0.5

mean(all_marksin50scale)

eva_marks=all_marksin50scale(1,:)

meanmarkofeva=mean(eva_marks)

antra_marks=all_marksin50scale(2,:)

meanmarkofantra=mean(antra_marks)

hasibul_marks=all_marksin50scale(3,:)

meanmarkofhaibul=mean(hasibul_marks)

mawa_marks=all_marksin50scale(4,:)

meanmarkofmawa=mean(mawa_marks)

sanjana_marks=all_marksin50scale(5,:)


meanmarkofsanjana=mean(sanjana_marks)


c=[94,95,96,97,98]

new_mark=[marks,c']




to_drop=new_mark
to_drop(:,4)



markof_antara_hasib_sanjana=marks([2,3,5],1:3)







